#!/bin/sh

sudo tune -f "$1"
