#!/bin/sh

sudo ./pifsq "Test" "$1"
