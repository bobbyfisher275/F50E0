#!/bin/sh

sudo ./piopera F5OEO 0.5 "$1"


